#!/bin/zsh

echo 'Beginning Run 1'

./OS_Assignment_4.out > run_1.txt

echo 'Beginning Run 2'

./OS_Assignment_4.out > run_2.txt

echo 'Beginning Run 3'

./OS_Assignment_4.out > run_3.txt

echo 'Beginning Run 4'

./OS_Assignment_4.out > run_4.txt

echo 'Complete!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!'
